<?php
  $hn="localhost";
  $un="id17887313_projectdbssp";
  $pw="Baha2015tata_";
  $db="id17887313_projectdb";
?>